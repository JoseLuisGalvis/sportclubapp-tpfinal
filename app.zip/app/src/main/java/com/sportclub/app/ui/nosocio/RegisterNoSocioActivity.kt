package com.sportclub.app.ui.nosocio

import androidx.appcompat.app.AppCompatActivity

class RegisterNoSocioActivity : AppCompatActivity()