package com.sportclub.app.ui.socio

import androidx.appcompat.app.AppCompatActivity

class RegisterSocioActivity : AppCompatActivity()